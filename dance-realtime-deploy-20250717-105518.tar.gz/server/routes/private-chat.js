const express = require('express');
const router = express.Router();
const PrivateChat = require('../models/PrivateChat');
const User = require('../models/User');
const { authenticateToken } = require('../middleware/auth');

// Получить все диалоги текущего пользователя
router.get('/chats', authenticateToken, async (req, res) => {
  try {
    const chats = await PrivateChat.findUserChats(req.user._id);
    
    // Добавляем информацию о собеседнике для каждого чата
    const chatsWithPartner = chats.map(chat => {
      const partner = chat.participants.find(p => p._id.toString() !== req.user._id.toString());
      const lastMessage = chat.messages.length > 0 ? chat.messages[chat.messages.length - 1] : null;
      
      return {
        _id: chat._id,
        partner: {
          _id: partner._id,
          name: partner.name,
          role: partner.role
        },
        lastMessage: lastMessage ? {
          content: lastMessage.content,
          timestamp: lastMessage.timestamp,
          sender: lastMessage.sender._id.toString() === req.user._id.toString() ? 'me' : 'partner'
        } : null,
        lastActivity: chat.lastActivity,
        unreadCount: chat.messages.filter(msg => 
          msg.sender._id.toString() !== req.user._id.toString() && !msg.isRead
        ).length
      };
    });

    res.json(chatsWithPartner);
  } catch (error) {
    console.error('Error fetching chats:', error);
    res.status(500).json({ message: 'Ошибка при загрузке диалогов' });
  }
});

// Получить сообщения конкретного диалога
router.get('/chats/:partnerId', authenticateToken, async (req, res) => {
  try {
    const { partnerId } = req.params;
    
    let chat = await PrivateChat.findChatBetween(req.user._id, partnerId);
    
    if (!chat) {
      // Если диалога нет, создаем пустой объект
      const partner = await User.findById(partnerId).select('name role');
      if (!partner) {
        return res.status(404).json({ message: 'Пользователь не найден' });
      }
      
      return res.json({
        _id: null,
        partner: {
          _id: partner._id,
          name: partner.name,
          role: partner.role
        },
        messages: []
      });
    }

    // Отмечаем сообщения как прочитанные
    const unreadMessages = chat.messages.filter(msg => 
      msg.sender._id.toString() !== req.user._id.toString() && !msg.isRead
    );
    
    unreadMessages.forEach(msg => {
      msg.isRead = true;
    });
    
    if (unreadMessages.length > 0) {
      await chat.save();
    }

    const partner = chat.participants.find(p => p._id.toString() !== req.user._id.toString());
    
    res.json({
      _id: chat._id,
      partner: {
        _id: partner._id,
        name: partner.name,
        role: partner.role
      },
      messages: chat.messages.map(msg => ({
        _id: msg._id,
        content: msg.content,
        timestamp: msg.timestamp,
        sender: {
          _id: msg.sender._id,
          name: msg.sender.name,
          isMe: msg.sender._id.toString() === req.user._id.toString()
        }
      }))
    });
  } catch (error) {
    console.error('Error fetching chat:', error);
    res.status(500).json({ message: 'Ошибка при загрузке диалога' });
  }
});

// Отправить сообщение
router.post('/chats/:partnerId/messages', authenticateToken, async (req, res) => {
  try {
    const { partnerId } = req.params;
    const { content } = req.body;

    if (!content || content.trim().length === 0) {
      return res.status(400).json({ message: 'Сообщение не может быть пустым' });
    }

    // Проверяем что получатель существует
    const partner = await User.findById(partnerId);
    if (!partner) {
      return res.status(404).json({ message: 'Пользователь не найден' });
    }

    // Ищем существующий диалог или создаем новый
    let chat = await PrivateChat.findChatBetween(req.user._id, partnerId);
    
    if (!chat) {
      chat = new PrivateChat({
        participants: [req.user._id, partnerId],
        messages: []
      });
    }

    // Добавляем новое сообщение
    const newMessage = {
      sender: req.user._id,
      content: content.trim(),
      timestamp: new Date()
    };

    chat.messages.push(newMessage);
    await chat.save();

    // Получаем полную информацию о сообщении
    await chat.populate('messages.sender', 'name role');
    const savedMessage = chat.messages[chat.messages.length - 1];

    const messageData = {
      _id: savedMessage._id,
      content: savedMessage.content,
      timestamp: savedMessage.timestamp,
      sender: {
        _id: savedMessage.sender._id,
        name: savedMessage.sender.name,
        isMe: true
      }
    };

    // Отправляем Socket.io событие для real-time обновления
    const io = req.app.get('io');
    if (io) {
      // Отправляем сообщение в комнату чата (для обоих участников)
      const chatId = chat._id.toString();
      io.to(chatId).emit('new-message', {
        chatId,
        message: {
          ...messageData,
          sender: {
            ...messageData.sender,
            isMe: false // Для получателя это не его сообщение
          }
        },
        partnerId: partnerId
      });
    }

    res.status(201).json(messageData);
  } catch (error) {
    console.error('Error sending message:', error);
    res.status(500).json({ message: 'Ошибка при отправке сообщения' });
  }
});

// Получить список всех пользователей для выбора собеседника
router.get('/users', authenticateToken, async (req, res) => {
  try {
          const users = await User.find({ 
        _id: { $ne: req.user._id } // Исключаем текущего пользователя
    }).select('name email role');

    res.json(users);
  } catch (error) {
    console.error('Error fetching users:', error);
    res.status(500).json({ message: 'Ошибка при загрузке пользователей' });
  }
});

module.exports = router; 