const mongoose = require('mongoose');

const privateMessageSchema = new mongoose.Schema({
  sender: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  content: {
    type: String,
    required: true,
    trim: true
  },
  timestamp: {
    type: Date,
    default: Date.now
  },
  isRead: {
    type: Boolean,
    default: false
  }
});

const privateChatSchema = new mongoose.Schema({
  participants: {
    type: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    }],
    required: true,
    validate: {
      validator: function(v) {
        return v.length === 2;
      },
      message: 'Private chat must have exactly 2 participants'
    }
  },
  messages: [privateMessageSchema],
  lastActivity: {
    type: Date,
    default: Date.now
  },
  isActive: {
    type: Boolean,
    default: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Индекс для быстрого поиска чатов по участникам
privateChatSchema.index({ participants: 1 });

// Автоматически обновляем lastActivity при добавлении сообщения
privateChatSchema.pre('save', function(next) {
  if (this.messages && this.messages.length > 0) {
    this.lastActivity = new Date();
  }
  next();
});

// Метод для поиска чата между двумя пользователями
privateChatSchema.statics.findChatBetween = function(userId1, userId2) {
  return this.findOne({
    participants: { $all: [userId1, userId2] }
  }).populate('participants', 'name email role')
    .populate('messages.sender', 'name role');
};

// Метод для получения всех чатов пользователя
privateChatSchema.statics.findUserChats = function(userId) {
  return this.find({
    participants: userId,
    isActive: true
  }).populate('participants', 'name email role')
    .populate('messages.sender', 'name role')
    .sort({ lastActivity: -1 });
};

module.exports = mongoose.model('PrivateChat', privateChatSchema); 