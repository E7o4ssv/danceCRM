// This component is deprecated - use Navbar.js instead
export default function Navigation() {
  return null;
} 